<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php
// phpinfo();
// echo("<h1>おはよう、PHP！</h1>");
$message="どうも、PHP！";
echo("<h1>".$message."</h1>");
?>
</body>
</html>
