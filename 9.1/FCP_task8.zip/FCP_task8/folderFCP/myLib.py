# -*- coding: utf-8 -*-
"""
Created on Sat Oct  3 12:12:29 2021

@author: KCG
"""

def bmi(height,weight): 
    """BMIを計算・表示する関数
    　入力は身長と体重"""
    bmi = weight / height**2 * 10000
    bmi = round(bmi, 1)
    if bmi < 18.5:
        message = "痩身"
    elif 25.0 <= bmi:
        message = "肥満"
    else:
        message = "標準体重"
    print("あなたの肥満度は",bmi,"で",message,"です")
