# -*- coding: utf-8 -*-
"""
Created on Sat Oct  3 12:12:29 2021

@author: KCG
"""

from folderFCP import myLib

print("あなたの肥満度を計算します")
weight = int(input("体重をkgで入力："))
height = int(input("身長をcmで入力："))
myLib.bmi(height,weight)  # 関数呼び出し


"""
from folderFCP.myLib import bmi

print("あなたの肥満度を計算します")
weight = int(input("体重をkgで入力："))
height = int(input("身長をcmで入力："))
bmi(height,weight)  # 関数呼び出し
"""