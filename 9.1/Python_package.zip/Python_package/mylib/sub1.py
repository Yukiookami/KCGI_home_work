def func_a():
    print('sub1モジュールのfunc_aが呼ばれた') 

def func_b():
    print('sub1モジュールのfunc_bが呼ばれた') 

