def func_a():
    print('sub2モジュールのfunc_aが呼ばれた') 
    
    
    