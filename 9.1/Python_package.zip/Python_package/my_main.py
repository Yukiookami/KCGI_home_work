# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 10:18:23 2021

@author: kcg
"""

# mylibパッケージのsub1,sub2モジュールインポート
from mylib import sub1, sub2

print('sub1モジュールのfunc_a関数呼出し') 
sub1.func_a()

print('sub1モジュールのfunc_b関数呼出し') 
sub1.func_b()

# sub2モジュールの同じ名前の関数func_aを呼出す
print('sub2モジュールのfunc_a関数呼出し') 
sub2.func_a()

