# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 10:18:23 2021

@author: kcg
"""

from mylib.sub1 import func_a

print('sub1モジュールのfunc_a関数呼出し') 
func_a()



