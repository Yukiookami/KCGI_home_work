<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
あなたのユーザIDは
<?php
echo($_POST['uid']);
?>
で、パスワードは
<?php
echo($_POST['pwd']);
?>
ですね。
<?php

?>
</body>
</html>
