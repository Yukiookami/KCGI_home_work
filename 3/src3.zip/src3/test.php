<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php
// phpinfo();
// echo("<h1>おはよう、PHP！</h1>");
$message="どうも、PHP！";
?>
今日は３回目の授業です。
<?php
echo("<h1>".$message."</h1>");
?>
</body>
</html>
